﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuManager : MonoBehaviour {

	//Load a new level or menu scene
    public void LoadOption(string name)
    {
        Application.LoadLevel(name);
    }
}
