﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SliderManager : MonoBehaviour {

	public void Slide_Changed(float newValue)
    {

    }
}
